<?php 
$a=[
    ['id'=>1, 'name'=>'SP1', 'price'=>10], 
    ['id'=>2, 'name'=>'SP2', 'price'=>12], 
    ['id'=>3, 'name'=>'SP3', 'price'=>13], 
    ['id'=>4, 'name'=>'SP4', 'price'=>14], 
];
$id =$_GET['n'];
if (isset($a[$id]))
    echo json_encode($a[$id]);
else echo json_encode( ['id'=>0, 'name'=>'']);