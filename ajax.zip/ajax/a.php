<?php 
echo $_GET['n']*$_GET['n'];
